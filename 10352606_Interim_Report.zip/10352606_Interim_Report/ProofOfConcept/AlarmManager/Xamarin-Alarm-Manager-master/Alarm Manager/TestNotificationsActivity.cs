﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Media;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;

namespace Alarm_Manager
{
    [Activity(Label = "TestNotificationsActivity")]
    public class TestNotificationsActivity : Activity
    {
        TextView txtInfo1;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.TestNotificationsLayout);
            //  ??Toolbar.SetTitle = "My Test Notification Layout";
            txtInfo1 = FindViewById<TextView>(Resource.Id.txtInfo1);

            txtInfo1.Text = "Info text wired up";


            Toast.MakeText(this, "Test Notification Activity Reached", ToastLength.Long).Show();


            //Intent intent = new Intent(this, typeof(Screen2Activity));
            ////StartActivity(intent);
            //const int pendindingIntentId = 0;
            //PendingIntent pendingIntent =
            //    PendingIntent.GetActivity(this, pendindingIntentId, intent, PendingIntentFlags.OneShot);

            // .SetContentIntent(pendingIntent)


            // instantiate builder and set notification elements
            //Notification.Builder builder = new Notification.Builder(context)

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .SetContentTitle("My 1st Notification")
                .SetContentText("Here is the content from my new notification.")
                .SetSmallIcon(Resource.Drawable.Icon)
                //Obsolete code !!!!
                .SetDefaults(NotificationCompat.DefaultVibrate)    // NotificationDefaults.Vibrate)
                
                .SetSound(RingtoneManager.GetDefaultUri(RingtoneType.Alarm))
                ;


            //// no lockscreen notifications before Android 5.0(API level 21)
            //if ((int)Android.OS.Build.VERSION.SdkInt >= 21)
            //{
            //    builder.SetVisibility(NotificationCompat.VisibilityPublic);
            //}

            // build notification
            Notification notification = builder.Build();

            // get the notification manager
            NotificationManager notificationManager =
                GetSystemService(Context.NotificationService) as NotificationManager;

            // publish the notification
            const int notificationId = 0;
            notificationManager.Notify(notificationId, notification);

        }//
    }//
}//